const codeBox = document.getElementById("code");
const language = document.getElementById("language");
const results = document.getElementById("results");
const resultCount = document.getElementById("resultCount");
const resultIcon = document.getElementById("resultIcon");
const statusText = document.getElementById("status");

const examples = {
  javascript: `function greet(name) {
  console.log("Hello " + name);
}

greet("World"`,
  python: `def greet(name):
    print("Hello " + name

greet("World")`,
  html: `<html>
<head>
  <title>Test</title>
</head>
<body>
  <h1>Hello World<h1>
</body>
</html>`,
  css: `.card {
  color: blue;
  background: white
  padding: 20px;
}`,
  json: `{
  "name": "Error Finder",
  "version": 1.0,
  "active": true,
}`
};

function lineOf(text, index) {
  return text.slice(0, Math.max(0,index)).split("\n").length;
}

function issue(type, line, message, fix) {
  return { type, line, message, fix };
}

function checkBalanced(code, pairs) {
  const stack = [];
  let quote = null;
  let escaped = false;
  const openings = new Set(Object.keys(pairs));
  const closings = new Set(Object.values(pairs));
  for (let i=0; i<code.length; i++) {
    const c = code[i];
    if (quote) {
      if (escaped) escaped = false;
      else if (c === "\\") escaped = true;
      else if (c === quote) quote = null;
      continue;
    }
    if (c === '"' || c === "'" || c === "`") { quote = c; continue; }
    if (openings.has(c)) stack.push({c, i});
    else if (closings.has(c)) {
      const last = stack.pop();
      if (!last || pairs[last.c] !== c) {
        return issue("Syntax Error", lineOf(code,i), `Unexpected closing '${c}'. A matching opening bracket is missing or misplaced.`, "Check the bracket pair on this line.");
      }
    }
  }
  if (quote) return issue("Syntax Error", lineOf(code, code.length), `The ${quote} string is not closed.`, `Add the missing ${quote} at the end of the string.`);
  if (stack.length) {
    const last = stack[stack.length - 1];
    return issue("Syntax Error", lineOf(code,last.i), `The '${last.c}' bracket is not closed.`, `Add the matching '${pairs[last.c]}' before the block ends.`);
  }
  return null;
}

function findErrors(code, lang) {
  const found = [];
  if (!code.trim()) return [issue("Empty Input", 1, "No code was entered.", "Paste your code into the editor and scan again.")];

  if (["javascript","python","json"].includes(lang)) {
    const bracketError = checkBalanced(code, {"(":")","[":"]","{":"}"});
    if (bracketError) found.push(bracketError);
  }

  if (lang === "javascript") {
    const lines = code.split("\n");
    lines.forEach((line, i) => {
      if (/\b(const|let|var)\s+\w+\s*=/.test(line) && !/[;{]\s*$/.test(line.trim()) && !line.includes("=>")) {
        found.push(issue("Possible Syntax Error", i+1, "This statement may be missing a semicolon.", "Add ; at the end of the statement."));
      }
      if (/\bconsole\.log\([^)]*$/.test(line)) {
        found.push(issue("Syntax Error", i+1, "console.log appears to be missing a closing parenthesis.", "Add ) to close console.log(...)."));
      }
    });
  }

  if (lang === "python") {
    const lines = code.split("\n");
    lines.forEach((line, i) => {
      const trimmed = line.trim();
      if (/^(if|for|while|def|class|elif|else|try|except|finally|with)\b/.test(trimmed) && !trimmed.endsWith(":")) {
        found.push(issue("Indentation / Syntax", i+1, "This Python block likely needs a colon.", "Add : at the end of the statement."));
      }
      if (/\b(print|input|len|str|int|float)\s*\([^)]*$/.test(line)) {
        found.push(issue("Syntax Error", i+1, "A function call appears to be missing a closing parenthesis.", "Add ) to close the function call."));
      }
    });
  }

  if (lang === "html") {
    const tags = [...code.matchAll(/<\/?([a-zA-Z0-9]+)[^>]*>/g)].map(m => ({tag:m[1].toLowerCase(), closing:m[0].startsWith("</"), index:m.index}));
    const stack = [];
    const voidTags = new Set(["meta","link","img","input","br","hr","source","area","base","embed","param","track","wbr"]);
    for (const t of tags) {
      if (voidTags.has(t.tag)) continue;
      if (!t.closing) stack.push(t);
      else {
        const last = stack.pop();
        if (!last || last.tag !== t.tag) {
          found.push(issue("HTML Error", lineOf(code,t.index), `Closing tag </${t.tag}> does not match the most recent opening tag.`, `Check the opening/closing pair for <${t.tag}>.`));
          break;
        }
      }
    }
    if (!found.length && stack.length) {
      const last = stack[stack.length-1];
      found.push(issue("HTML Error", lineOf(code,last.index), `The <${last.tag}> tag is not closed.`, `Add </${last.tag}> where the element ends.`));
    }
  }

  if (lang === "css") {
    const bracketError = checkBalanced(code, {"{":"}"});
    if (bracketError) found.push(bracketError);
    code.split("\n").forEach((line,i) => {
      const t = line.trim();
      if (t.includes(":") && !t.endsWith(";") && !t.endsWith("{") && !t.endsWith("}")) {
        found.push(issue("CSS Warning", i+1, "This CSS property may be missing a semicolon.", "Add ; at the end of the property."));
      }
    });
  }

  if (lang === "json") {
    try {
      JSON.parse(code);
    } catch (e) {
      const match = String(e.message).match(/position (\d+)/i);
      const pos = match ? Number(match[1]) : 0;
      found.push(issue("JSON Syntax Error", lineOf(code,pos), e.message, "Check commas, quotes, brackets, and JSON value types."));
    }
  }

  return found.slice(0, 8);
}

function renderIssues(issues) {
  resultCount.textContent = `${issues.length} issue${issues.length === 1 ? "" : "s"} found`;
  resultIcon.textContent = issues.length ? "!" : "✓";
  resultIcon.className = `result-icon ${issues.length ? "bad" : "ok"}`;

  if (!issues.length) {
    results.className = "results";
    results.innerHTML = `<div class="success-box"><div><div class="check">✓</div><h4>No obvious errors found</h4><p>The basic checks passed. Always run your code to verify its actual behavior.</p></div></div>`;
    return;
  }

  results.className = "results";
  results.innerHTML = issues.map((x, i) => `
    <div class="issue">
      <div class="issue-head"><strong>${i+1}. ${escapeHTML(x.type)}</strong><span class="line">Line ${x.line}</span></div>
      <p>${escapeHTML(x.message)}</p>
      <div class="fix">Fix → ${escapeHTML(x.fix)}</div>
    </div>
  `).join("");
}

function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
}

document.getElementById("checkBtn").addEventListener("click", () => {
  statusText.textContent = "Scanning...";
  const issues = findErrors(codeBox.value, language.value);
  renderIssues(issues);
  statusText.textContent = issues.length ? "Scan complete" : "No obvious issues";
});

document.getElementById("sampleBtn").addEventListener("click", () => {
  codeBox.value = examples[language.value];
  statusText.textContent = "Example loaded";
  renderIssues(findErrors(codeBox.value, language.value));
});

document.getElementById("clearBtn").addEventListener("click", () => {
  codeBox.value = "";
  results.className = "results empty";
  results.innerHTML = `<div class="empty-icon">⌕</div><h4>Ready to scan</h4><p>Paste code on the left and click <b>Find Errors</b>.</p>`;
  resultCount.textContent = "No scan yet";
  resultIcon.textContent = "✓";
  resultIcon.className = "result-icon";
  statusText.textContent = "Ready to check";
});

document.getElementById("themeBtn").addEventListener("click", () => {
  document.body.classList.toggle("light");
  document.getElementById("themeBtn").textContent = document.body.classList.contains("light") ? "☾" : "☀";
});
